﻿define camille = Character("Camille")
define receptionist = Character("Receptionniste")
define professor = Character("Professeur")
define lucas = Character("Lucas")

transform character_zoom:
    zoom 1.5
    xalign 0.5
    yalign 1.0

transform bg_zoom:
    zoom 1.3
    xcenter 0.5
    ycenter 0.5

transform classroom_zoom:
    zoom 1.8
    xcenter 0.5
    ycenter 0.5

transform character_classroom:
    zoom 1.5
    xalign 0.5
    yalign 1.0

image camille happy = "camille-feliz.png"
image camille preoccupied = "camille-preoc.png"
image camille horrified = "camille-horror.png"
image lucas happy = "lucas-feliz.png"
image lucas horrified = "lucas-horror.png"
image professor happy = "profesor-happy.png"
image professor preoccupied = "profesor-preocupado.png"
image professor horrified = "profesor-horror.png"
image receptionist happy = "rec-feliz.png"
image receptionist horrified = "rec-horror.png"
image bg bakery = "bg panaderia.png"
image bg cafe = "bg cafe.png"
image bg lecturehall = "bg lecturehall.jpg"
image bg pueblo = "bg pueblo.png"
image bg hotel = "bg hotel.png"


label start:

    $ score = 0

    scene bg bakery at bg_zoom
    show camille happy at character_zoom

    camille "Bienvenue en France ! Aujourd'hui, tu vas pratiquer la politesse et les registres."
    camille "Premiere situation : tu entres dans une boulangerie a Paris."

    menu:
        "Bonjour Madame.":
            $ score += 1
            show camille happy at character_zoom
            camille "Tres bien ! En France, on dit bonjour avant de demander quelque chose."
        "Donnez-moi un croissant.":
            show camille preoccupied at character_zoom
            camille "Attention. C'est mieux de dire bonjour d'abord."
        "Salut, ca va ?":
            show camille horrified at character_zoom
            camille "Avec une vendeuse inconnue, le registre formel est preferable."

    scene bg hotel at bg_zoom
    show receptionist happy at character_zoom

    receptionist "Bonjour, vous avez besoin d'aide ?"

    menu:
        "Bonjour, pourriez-vous m'aider ?":
            $ score += 1
            show receptionist happy at character_zoom
            receptionist "Bien sur, je vous ecoute."
        "Tu peux m'aider ?":
            show receptionist horrified at character_zoom
            receptionist "Attention : dans un hotel, on utilise generalement 'vous'."
        "He, aide-moi.":
            show receptionist horrified at character_zoom
            receptionist "Ce n'est pas tres poli."

    scene bg cafe at bg_zoom
    show lucas happy at character_zoom

    lucas "Salut !"

    menu:
        "Salut, tu vas bien ?":
            $ score += 1
            show lucas happy at character_zoom
            lucas "Oui, tres bien !"
        "Bonjour Monsieur, comment allez-vous ?":
            show lucas horrified at character_zoom
            lucas "C'est correct, mais trop formel avec un ami."
        "Pourriez-vous m'indiquer le cafe ?":
            show lucas horrified at character_zoom
            lucas "C'est une phrase formelle, pas naturelle avec un ami."

    scene bg pueblo at bg_zoom
    show camille happy at character_zoom

    camille "Et maintenant, la vie quotidienne : ville ou campagne ?"
    camille "Quelle phrase decrit la vie a la campagne ?"

    menu:
        "La vie est souvent plus calme.":
            $ score += 1
            show camille happy at character_zoom
            camille "Exact ! La campagne est plus calme."
        "Le rythme de vie est plus rapide.":
            show camille preoccupied at character_zoom
            camille "Cette phrase decrit plutot la ville."
        "Il faut toujours prendre le metro.":
            show camille horrified at character_zoom
            camille "Le metro est surtout associe a la ville."

    scene bg lecturehall at classroom_zoom
    show professor happy at character_classroom

    professor "Bonjour. Vous avez une question ?"

    menu:
        "Excusez-moi, pourriez-vous repeter ?":
            $ score += 1
            show professor happy at character_classroom
            professor "Bien sur."
        "Tu repetes ?":
            show professor preoccupied at character_classroom
            professor "Attention : avec un professeur, on utilise souvent 'vous'."
        "Salut, repete.":
            show professor horrified at character_classroom
            professor "Cette phrase n'est pas polie."

    scene bg lecturehall at classroom_zoom
    show camille happy at character_classroom

    camille "Derniere activite : ecris une phrase formelle pour demander de l'aide."

    $ phrase = renpy.input("Ta phrase :")
    $ phrase = phrase.strip()

    camille "Merci ! Ta phrase est : [phrase]"

    if score == 5:
        show camille happy at character_zoom
        camille "Excellent ! Tu sais adapter ton langage selon la situation."
    elif score >= 3:
        show camille preoccupied at character_zoom
        camille "Bien ! Tu comprends la difference entre registre formel et informel."
    else:
        show camille horrified at character_zoom
        camille "Continue a pratiquer : pense a la personne, au lieu et a la politesse."

    return
