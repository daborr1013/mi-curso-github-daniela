﻿# Coloca el código de tu juego en este archivo.

# Declara los personajes usados en el juego como en el ejemplo:

define camille = Character("Camille")

image camille happy = Transform("camille-feliz.png", zoom=1.35)
image camille worried = Transform("camille-preoc.png", zoom=1.35)
image camille horror = Transform("camille-horror.png", zoom=1.35)
image bg meadow = im.Scale("bg meadow.jpg", config.screen_width, config.screen_height)

label start:

    $ score = 0

    scene bg meadow
    show camille happy

    camille "Salut ! Aujourd'hui, je vais te raconter une journée bizarre."
    camille "Quand j'étais étudiante, ma vie était très différente."

    camille "Complète la phrase : Quand j'étais étudiante, je..."

    menu:
        "me levais toujours à 7h.":
            $ score += 1
            show camille happy
            camille "Correct ! Pour une habitude dans le passé, on utilise l'imparfait."
        "me suis levée toujours à 7h.":
            show camille worried
            camille "Pas exactement. Ici, c'est une habitude, donc il faut l'imparfait."
        "me lève toujours à 7h.":
            show camille horror
            camille "Attention, cette phrase est au présent."

    camille "Hier matin, le temps était mauvais."
    camille "Quelle phrase décrit le contexte ?"
    show camille worried

    menu:
        "Il faisait froid et il pleuvait.":
            $ score += 1
            show camille happy
            camille "Très bien ! L'imparfait sert à décrire une situation."
        "Il a fait froid et il a plu quand je sortais.":
            show camille worried
            camille "Pas tout à fait. Pour le contexte général, on préfère l'imparfait."
        "Il fait froid et il pleut.":
            show camille horror
            camille "Attention, cette phrase est au présent."

    camille "Normalement, je prenais le bus. Mais hier..."
    show camille worried

    menu:
        "j'ai pris le métro.":
            $ score += 1
            show camille happy
            camille "Exact ! C'est une action ponctuelle et terminée."
        "je prenais le métro.":
            show camille worried
            camille "Ici, on parle d'une action précise d'hier."
        "je prends le métro.":
            show camille horror
            camille "Attention, cette phrase est au présent."

    camille "Le soir, je regardais la télévision..."
    show camille worried

    menu:
        "quand mon ami a appelé.":
            $ score += 1
            show camille happy
            camille "Bravo ! Une action en cours + une action ponctuelle."
        "quand mon ami appelait.":
            show camille worried
            camille "Presque, mais l'appel est une action ponctuelle."
        "quand mon ami appelle.":
            show camille horror
            camille "Attention, cette phrase est au présent."

    camille "Maintenant, écris une phrase sur ta routine quand tu étais enfant."

    $ phrase = renpy.input("Quand j'étais enfant,...")
    $ phrase = phrase.strip()

    camille "Merci ! Ta phrase est : Quand j'étais enfant, [phrase]"

    if score == 4:
        show camille happy
        camille "Excellent ! Tu comprends très bien l'imparfait et le passé composé."
    elif score >= 2:
        show camille worried
        camille "Bien ! Tu peux encore pratiquer un peu."
    else:
        show camille horror
        camille "Ce n'est pas grave. Relis la différence entre habitude, contexte et action ponctuelle."

    return
