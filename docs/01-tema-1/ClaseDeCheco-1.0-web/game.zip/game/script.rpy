﻿# Coloca el código de tu juego en este archivo.

# Declara los personajes usados en el juego como en el ejemplo:

define p = Character("Profesor")
define o = Character("Alumnos")
define s = Character("Alumno 1")
define t = Character("Alumno 2")
define n = Character("Narrador")

# Variable para rastrear el resultado del quiz
default quiz_correct = False

image hallway = im.Scale("images/class.jpg", 1920, 1080)
image bg lecturehall = im.Scale("images/bg lecturehall.jpg", 1920, 1080)
image p = im.Scale("images/schue.png", 500, 700)
image o = im.Scale("images/1D.png", 500, 700)
image s = im.Scale("images/sabrina.png", 500, 700)
image t = im.Scale("images/taylor.png", 500, 700)

# El juego comienza aquí.

label start:

    # Muestra una imagen de fondo: Aquí se usa un marcador de posición por
    # defecto. Es posible añadir un archivo en el directorio 'images' con el
    # nombre "bg room.png" or "bg room.jpg" para que se muestre aquí.

    scene hallway

    # Muestra un personaje: Se usa un marcador de posición. Es posible
    # reemplazarlo añadiendo un archivo llamado "profesor.png" al directorio
    # 'images'.

    n "En un día soleado, los alumnos de la universidad van llegando al aula para dar su primera clase de checo."

    show s at left
    show t at right

    t "Tía, vamos que llegamos tarde a clase."
    s "¿Cómo será este profesor? Me da curiosidad saber cómo serán sus clases."

    scene bg lecturehall

    n "Las alumnas por fin entran a clase pero está vacía."

    s "Em... ¿el profesor no debería estar aquí ya?"
    t "Si... que raro."

    hide s
    hide t

    n "De repente, el profesor sale de debajo de la mesa y las asusta."

    show p at right

    p "¡Dobrý den, chicas! Perdonadme por asustaros, es que me gusta hacer una entrada dramática a mis clases."
    n "Las chicas le miran sorprendidas pero no dicen nada. El profesor se ríe igualmente y les dice que se sienten. Al rato, llegan otros chicos y el profesor les hace lo mismo."

    show o at left

    o "¡Aaah!"
    p "Jajajaja, lo siento chicos, me gusta empezar de esta manera mis clases. Sentáos donde queráis."

    hide o

    n "Cuando ya están todos los alumnos sentados, el profesor empieza la clase."
    p "Bueno chicos, como ya habréis escuchado cuando os saludé, he dicho Dobrý den. ¿Qué créeis que significa?"

    show s at left

    s "Em... ¿hola?"
    p "¡Correcto! Pero no es un hola común, es un hola formal. En checo, hay dos formas de decir hola, una formal y otra informal. ¿Sabéis cuál es la forma informal?"

    hide s
    show o at left

    o "Ni idea, la verdad."
    p "Pues es Ahoj. Es una forma de saludo muy común entre amigos, y aunque parezco muy amigable, es mejor que uséis el saludo formal conmigo, ¿vale? Jajaja."

    n "Hay un pequeño silencio incómodo, pero el profesor continúa con la clase de saludos y despedidas en checo."

    hide o

    p "Finalmente, tenemos las despedidas en checo que también tienen una forma formal e informal. La forma formal es Na shledanou, y la forma informal es Ahoj o Čau, igual que el saludo informal. ¿Os gustaría que os diera un pequeño resumen de lo que hemos visto hoy?"
    
    show t at left

    t "Sí, por favor."

    hide t

    p "¡Perfecto! Para saludar a alguien de forma formal, decimos Dobrý den, y para despedirnos de forma formal, decimos Na shledanou. Para saludar a alguien de forma informal, decimos Ahoj, y para despedirnos de forma informal, decimos Ahoj o Čau."

    n "El profesor sonríe y abre un portátil para comenzar con una actividad interactiva."
    p "Ahora vamos a hacer un pequeño quiz para ver si habéis aprendido. ¡Vamos allá!"

    # Comienza el quiz
    jump quiz_question_1

label quiz_question_1:
    p "Primera pregunta: Si entras en clase y quieres saludarme, ¿qué debes decir?"
    
    menu:
        "Ahoj":
            jump quiz_q1_incorrect_ahoj
        "Dobrý den":
            jump quiz_q1_correct
        "Čau":
            jump quiz_q1_incorrect_cau

label quiz_q1_correct:
    $ quiz_correct = True
    p "¡Muy bien, eso es correcto! Dobrý den es el saludo formal que debes usar conmigo en clase."
    
    show t at left
    t "¡Genial! Me he acordado."
    hide t
    
    jump quiz_complete

label quiz_q1_incorrect_ahoj:
    $ quiz_correct = False
    p "No exactamente... Ahoj es informal, y es mejor que uses el saludo formal conmigo en clase."
    p "La respuesta correcta es Dobrý den. Es un saludo mucho más apropiado para un profesor."
    
    show s at left
    s "Ah, tienes razón, claro."
    hide s
    
    jump quiz_complete

label quiz_q1_incorrect_cau:
    $ quiz_correct = False
    p "Casi, pero no... Čau también es un saludo informal, como Ahoj."
    p "La respuesta correcta es Dobrý den, que es el saludo formal correcto para entrar a clase."
    
    show o at left
    o "Entiendo... gracias por la aclaración."
    hide o
    
    jump quiz_complete


label quiz_complete:
    if quiz_correct:
        jump ending_correct
    else:
        jump ending_incorrect

label ending_correct:
    n "El profesor cierra el portátil y sonríe ampliamente, muy satisfecho."
    p "¡Excelente trabajo, chicos! ¡Habéis aprendido perfectamente los saludos en checo! Estoy muy impresionado con vuestro desempeño."

    hide p
    
    show t at left
    show s at right
    show o at center

    n "Los alumnos se miran entre sí, sorprendidos por lo bien que les ha ido en el quiz a pesar de ser su primera clase de checo."

    hide s
    hide t
    hide o
    
    show p at center

    p "En serio, esto promete mucho para el resto del semestre. ¡Estoy emocionado de enseñaros más! En la próxima clase aprenderemos más vocabulario. ¡Que tengáis un excelente día!"
    
    n "Los alumnos salen del aula sonriendo y hablando sobre lo bien que les fue la clase a pesar de la excentridad del profesor."
    
    # Finaliza el juego
    return

label ending_incorrect:
    n "El profesor cierra el portátil con una expresión comprensiva."
    p "No os preocupéis, chicos. Esto es solo el comienzo. La práctica hace la perfección, así que en la próxima clase reforzaremos estos conceptos."
    
    show s at left
    s "Tienes razón... seguro que la próxima nos irá mejor."
    hide s
    
    show o at right
    o "Sí, necesitamos practicar más."
    hide o
    
    p "Exacto, esa es la actitud correcta. No os desaniméis, todos cometemos errores cuando aprendemos una lengua nueva. ¡Lo importante es seguir intentándolo! Nos vemos en la próxima clase. ¡Adiós!"
    
    n "Los alumnos recogen sus cosas un poco desmoralizados pero con la determinación de estudiar más para la próxima clase."
    
    # Finaliza el juego
    return
